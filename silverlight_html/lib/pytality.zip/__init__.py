import term
import boxtypes
import buffer

colors = term.colors
