import event, state

import logging
log = logging.getLogger('term')

import pytality

def init():
    pytality.term.init(height=state.config.height, width=state.config.width)

def settitle(*args,**kwargs):
    pytality.term.set_title(*args,**kwargs)

def restore():
    pytality.term.clear()
    pytality.term.reset()

def reset():
    pytality.term.reset()

def draw_buffer(*args,**kwargs):
    pytality.term.draw_buffer(*args,**kwargs)
    
class BoxDouble:
    blank = ' '
    horiz = chr(0xCD)
    vert = chr(0xBA)
    tl = chr(0xC9)
    bl = chr(0xC8)
    tr = chr(0xBB)
    br = chr(0xBC)

class BoxSingle(BoxDouble):
    horiz = chr(0xC4)
    vert = chr(0xB3)
    tl = chr(0xDA)
    bl = chr(0xC0)
    tr = chr(0xBF)
    br = chr(0xD9)




class BoxMessage(BoxDouble):
    vert = chr(0xB3)
    tr = chr(0xB8)
    br = chr(0xBE)
    cur_top = chr(0xD1)
    cur_bottom = chr(0xCF)
    cur = chr(0xD8)

class Pointer:
    left = chr(0x10)
    right = chr(0x11)


class Room:
    player = chr(2)

import time
times = [time.time()]
@event.on('flip')
def flip():
    times.append(time.time())
    pytality.term.flip()

#oh this is filthy
for color_name, color_value in pytality.colors.__dict__.items():
    globals()[color_name] = color_value

def getkey():
    '''
        Get a key of keyboard input. Returns 1 character or the name of the special key.
        Some special keys are hijacked and get events fired instead.
    '''
    while True:
        key = pytality.term.raw_getkey()
        
        if key == 'f':
            log.debug('fps check')
            log.debug("Times: %r", times)
            prev = times[0]
            rel_times = []
            for t in times[1:]:
                rel_times.append(t - prev)
                prev = t
            log.debug("Rel Times: %r", rel_times)
            log.debug("Max: %.2f Min: %.2f Avg: %.2f", max(rel_times), min(rel_times), sum(rel_times) / len(rel_times))

        if key is None:
            continue
        if key in ['home', 'pgup', 'pgdn', 'end']:
            #message scroll
            if key == 'home': event.fire('scroll', home=True)
            if key == 'pgup': event.fire('scroll', rel= -1)
            if key == 'pgdn': event.fire('scroll', rel= 1)
            if key == 'end': event.fire('scroll', end=True)
        elif key == '\x03':
            #ctrl-c
            event.fire('ctrl-c')
        else:
            return key
