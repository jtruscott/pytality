import event
from player import Player

import logging
log = logging.getLogger('state')

mode = "title"
running = True
class config:
    #configuration defaults, overridden by config.json
    width = 120
    height = 60

    viewport_width = 74
    viewport_height = 50

    no_sound = False

#the game's player
player = None
found_key = False

#global mod for power scaling
global difficulty_level
difficulty_level = 0

class StateChanged(Exception):
    """
        raise this to bubble all the way back to
        the state loop in game.py, immediately
    """
    pass

@event.on('setup')
def load_config():
    pass

def new_state():
    global player
    player = Player()

def load_state():
    pass
def save_state():
    pass
