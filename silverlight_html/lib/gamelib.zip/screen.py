import re
import pytality
import term

import logging
log = logging.getLogger('screen')

class AttrHack:
    @property
    def data(self):
        return self._data
    @data.setter
    def data(self, val):
        self._data = val

class Buffer(AttrHack, pytality.buffer.Buffer):
    pass

class Text(AttrHack, pytality.buffer.PlainText):
    pass

class RichText(AttrHack, pytality.buffer.RichText):
    pass


#----------------------------------------------------------------------

def make_box(*args, **kwargs):
    buf = pytality.buffer.Box(*args, **kwargs)
    return buf


left_pointer = Text(fg=term.WHITE, bg=term.BLACK, message=term.Pointer.left)
right_pointer = Text(fg=term.WHITE, bg=term.BLACK, message=term.Pointer.right)
